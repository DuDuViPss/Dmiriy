﻿#include <iostream>
using namespace std;

int main() {
	setlocale(LC_ALL, "RU");
	int n = 0, z = 1, p;
	while((n < 3) || (n % 2 == 0)) {
		cout << "Введите N (нечётное N > 3): ";
		cin >> n;
	}
	p = (n - 1) / 2;
	for (int i = 1; i <= (n + 1) / 2; ++i) {
		cout << endl;
		for (int j = 1; j <= p; ++j) {
			cout << ' ';
		}
		--p;
		for (int j = 1; j <= z; ++j) {
			cout << "*";
		}
		z += 2;
	}
}